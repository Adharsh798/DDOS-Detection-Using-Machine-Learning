
import os
import joblib

def load_model(attack_type, algorithm):
    model_path = os.path.abspath(f"models/{attack_type}_{algorithm}_model.pkl")
    print(f"Loading model from: {model_path}")
    
    model = joblib.load(model_path)
    
    # Check the type of model
    print(f"Model type for {attack_type} and {algorithm}: {type(model)}")
    
    if not hasattr(model, 'predict'):
        raise Exception(f"Model for {attack_type} and {algorithm} does not have a 'predict' method.")
    
    return model
